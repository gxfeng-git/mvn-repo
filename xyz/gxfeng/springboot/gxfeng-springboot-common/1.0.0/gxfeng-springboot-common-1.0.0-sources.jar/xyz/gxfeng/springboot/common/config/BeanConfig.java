package xyz.gxfeng.springboot.common.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.json.JsonWriteFeature;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import xyz.gxfeng.springboot.common.util.DateUtil;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @desc BeanConfig
 * @date 2023-02-04 20:20:52
 */
@Configuration
public class BeanConfig {

    @Bean(name = "mappingJackson2HttpMessageConverter")
    public MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter() {
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        JavaTimeModule javaTimeModule = new JavaTimeModule();
        javaTimeModule.addSerializer(LocalDateTime.class, new LocalDateTimeSerializer(DateTimeFormatter.ofPattern(DateUtil.YYYY_MM_DD_HH_MM_SS)));
        javaTimeModule.addDeserializer(LocalDateTime.class, new LocalDateTimeDeserializer(DateTimeFormatter.ofPattern(DateUtil.YYYY_MM_DD_HH_MM_SS)));
        converter.setObjectMapper(Jackson2ObjectMapperBuilder.json().createXmlMapper(false)
                .serializationInclusion(JsonInclude.Include.ALWAYS)
                .defaultViewInclusion(false)
                .simpleDateFormat(DateUtil.YYYY_MM_DD_HH_MM_SS)
                .locale(Locale.getDefault())
                .timeZone(TimeZone.getDefault())
                .modules(javaTimeModule)
                .featuresToEnable(
                        JsonGenerator.Feature.WRITE_BIGDECIMAL_AS_PLAIN,
                        JsonWriteFeature.WRITE_NUMBERS_AS_STRINGS.mappedFeature(),
                        JsonWriteFeature.WRITE_NAN_AS_STRINGS.mappedFeature(),
                        SerializationFeature.WRITE_ENUMS_USING_TO_STRING
                )
                .featuresToDisable(
                        DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
                        SerializationFeature.FAIL_ON_EMPTY_BEANS
                )
                .build()
        );
        List<MediaType> mediaTypes = new ArrayList<>();
        mediaTypes.add(MediaType.valueOf(MediaType.TEXT_PLAIN_VALUE + ";charset=UTF-8"));
        mediaTypes.add(MediaType.valueOf(MediaType.TEXT_HTML_VALUE + ";charset=UTF-8"));
        mediaTypes.add(MediaType.valueOf(MediaType.APPLICATION_JSON_VALUE + ";charset=UTF-8"));
        mediaTypes.add(MediaType.valueOf("application/vnd.spring-boot.actuator.v3+json;charset=UTF-8"));
        converter.setSupportedMediaTypes(mediaTypes);
        return converter;
    }
}
