package xyz.gxfeng.springboot.common;

import org.springframework.core.MethodParameter;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.http.server.ServletServerHttpResponse;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.AsyncHandlerMethodReturnValueHandler;
import org.springframework.web.method.support.HandlerMethodReturnValueHandler;
import org.springframework.web.method.support.ModelAndViewContainer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description
 * @date 2022/10/21
 */
public class WebHandlerMethodReturnValueHandler implements HandlerMethodReturnValueHandler, AsyncHandlerMethodReturnValueHandler {

    private HttpMessageConverter<?> httpMessageConverter;

    public WebHandlerMethodReturnValueHandler() {
        this.httpMessageConverter = new MappingJackson2HttpMessageConverter();
    }

    public WebHandlerMethodReturnValueHandler(HttpMessageConverter httpMessageConverter) {
        this.httpMessageConverter = httpMessageConverter;
    }

    public static void write(Result body, MediaType mediaType, ServletServerHttpResponse response, HttpMessageConverter httpMessageConverter) throws IOException {
        if (null == httpMessageConverter) {
            httpMessageConverter = new MappingJackson2HttpMessageConverter();
        }
        httpMessageConverter.write(body, mediaType, response);
    }

    public static void write(Result body, MediaType mediaType, ServletServerHttpResponse response) throws IOException {
        write(body, mediaType, response, null);
    }

    @Override
    public boolean isAsyncReturnValue(Object returnValue, MethodParameter returnType) {
        return supportsReturnType(returnType);
    }

    @Override
    public boolean supportsReturnType(MethodParameter returnType) {
        // 必须有ResponseBody注解 必须没有UnBodyAdvice 必须返回类型不是ResponseEntity
        return (AnnotatedElementUtils.hasAnnotation(returnType.getContainingClass(), ResponseBody.class) ||
                returnType.hasMethodAnnotation(ResponseBody.class))
                && !(AnnotatedElementUtils.hasAnnotation(returnType.getContainingClass(), UnBodyAdvice.class) ||
                returnType.hasMethodAnnotation(UnBodyAdvice.class))
                && !ResponseEntity.class.equals(returnType.getMethod().getReturnType());
    }

    @Override
    public void handleReturnValue(Object returnValue, MethodParameter returnType, ModelAndViewContainer mavContainer, NativeWebRequest webRequest) throws Exception {
        mavContainer.setRequestHandled(true);
        Result body = null;
        if (returnValue instanceof Result) {
            body = (Result) returnValue;
        } else {
            body = Result.success(() -> returnValue);
        }
        ServletServerHttpRequest request = createInputMessage(webRequest);
        ServletServerHttpResponse response = createOutputMessage(webRequest);
        response.setStatusCode(body.getStatus());
        write(body, MediaType.APPLICATION_JSON, response, httpMessageConverter);
    }

    protected ServletServerHttpRequest createInputMessage(NativeWebRequest webRequest) {
        HttpServletRequest servletRequest = webRequest.getNativeRequest(HttpServletRequest.class);
        Assert.state(servletRequest != null, "No HttpServletRequest");
        return new ServletServerHttpRequest(servletRequest);
    }

    protected ServletServerHttpResponse createOutputMessage(NativeWebRequest webRequest) {
        HttpServletResponse response = webRequest.getNativeResponse(HttpServletResponse.class);
        Assert.state(response != null, "No HttpServletResponse");
        return new ServletServerHttpResponse(response);
    }
}
