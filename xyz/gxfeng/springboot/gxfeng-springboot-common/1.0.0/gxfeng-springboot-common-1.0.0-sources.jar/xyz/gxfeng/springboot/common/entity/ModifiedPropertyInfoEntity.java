package xyz.gxfeng.springboot.common.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description
 * @date 2022/6/28
 */
@Data
public class ModifiedPropertyInfoEntity implements Serializable {
    /**
     * 发生变化的属性名称
     */
    private String propertyName;
    /**
     * 发生变化的属性注释
     */
    private String propertyComment;
    /**
     * 修改前的值
     */
    private Object oldValue;
    /**
     * 修改后的值
     */
    private Object newValue;
}
