package xyz.gxfeng.springboot.common;

import com.baomidou.mybatisplus.core.metadata.IPage;
import lombok.Data;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

@Data
public class PageData<T> {

    /**
     * 总数
     */
    private long total;

    /**
     * 当前list
     */
    private List<T> list;

    /**
     * 当前页数
     */
    private int pageNum;

    /**
     * 每页显示条数
     */
    private int pageSize;

    public PageData(long total, List<T> list, int pageNum, int pageSize) {
        this.total = total;
        this.list = list;
        this.pageNum = pageNum;
        this.pageSize = pageSize;
    }

    public PageData(List<T> list, int pageNum, int pageSize) {
        this.total = list.size();
        this.list = list;
        this.pageNum = pageNum;
        this.pageSize = pageSize;
    }

    public PageData(List<T> list) {
        this.total = list.size();
        this.list = list;
        this.pageNum = 1;
        this.pageSize = 10;
    }

    public PageData(IPage<T> page) {
        this.list = page.getRecords();
        this.total = page.getTotal();
        this.pageNum = Math.toIntExact(page.getCurrent());
        this.pageSize = Math.toIntExact(page.getSize());
    }

    public static <D, R> PageData<R> convert(IPage<D> page, Function<D, R> function) {
        List<R> collect = page.getRecords().stream().map(item -> function.apply(item)).collect(Collectors.toList());
        return new PageData<R>(page.getTotal(), collect, Math.toIntExact(page.getCurrent()), Math.toIntExact(page.getSize()));
    }
}
