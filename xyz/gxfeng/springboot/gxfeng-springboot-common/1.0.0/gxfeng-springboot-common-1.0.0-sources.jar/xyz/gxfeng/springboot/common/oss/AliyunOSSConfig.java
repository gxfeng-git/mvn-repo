package xyz.gxfeng.springboot.common.oss;

import lombok.Data;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description
 * @date 2021/12/18
 */
@Data
@Configuration
@ConditionalOnProperty(value = {"accessKeyId", "accessKeySecret", "endpoint", "bucketName"}, prefix = "aliyun.oss")
@ConfigurationProperties(prefix = "aliyun.oss")
public class AliyunOSSConfig {

    private String accessKeyId;

    private String accessKeySecret;

    private String endpoint;

    private String bucketName;
}
