package xyz.gxfeng.springboot.common.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableLogic;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description
 * @date 2021/12/16
 */
@Data
public abstract class BaseEntity implements Serializable {

    /**
     * 备注
     */
    @ApiModelProperty("备注")
    private String remark;

    /**
     * 拓展
     */
    @ApiModelProperty("拓展")
    private String memo;

    /**
     * 是否启用(1:已启用/0:未启用)
     */
    @ApiModelProperty("是否启用(1:已启用/0:未启用)")
    private Integer isEnabled;

    /**
     * 是否逻辑删除(1:已删除/0:未删除)
     */
    @TableLogic(value = "0", delval = "1")
    @ApiModelProperty("是否逻辑删除(1:已删除/0:未删除)")
    private Integer isDeleted;

    /**
     * 创建者编号
     */
    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty("创建者编号")
    private String createdBy;

    /**
     * 修改者编号
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("修改者编号")
    private String updatedBy;

    /**
     * 创建者姓名
     */
    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty("创建者姓名")
    private String createdByName;

    /**
     * 修改者姓名
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("修改者姓名")
    private String updatedByName;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date createdAt;

    /**
     * 修改时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("修改时间")
    private Date updatedAt;
}
