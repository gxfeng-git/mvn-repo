package xyz.gxfeng.springboot.common.util;

import java.util.Calendar;
import java.util.Date;
import java.util.Set;

/**
 * 日期处理的工具类
 * 使用了Julian整数型日期，通过简单+*-/就可以对日期进行各种操作，效率较高
 *
 * @author shengwang.chen
 */
public class DateUtility {
    public static final int SECONDS_PERDAY = 86400;
    public static final int DEFALUT_TIMEZONE = 0xFFFF;

    private static final Set<Integer> holidays = null;
    private static final int lastUpdateDate = -1; // 最后更新日期，每天更新一次，以防数据变更

    /**
     * 把日期转换成Julian整数日期
     */
    static public int date2int(int year, int month, int day) {
        int a = (14 - month) / 12;
        year += 4800 - a;    // 4801 B.C. is a century year and also a leap year.
        month += 12 * a - 3;
        return day + (153 * month + 2) / 5 + year * 365 + (year >> 2) - year / 100 + year / 400 - 32045;
    }

    /**
     * 把日期转换成Julian整数日期
     */
    static public int date2int(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return date2int(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DATE));
    }

    /**
     * 将一个格式为"YYYY-MM-DD"的日期转换成一个整数日期
     *
     * @param dateStr
     * @return
     */
    static public int date2int(String dateStr) {
        int[] digits = parse(dateStr);
        if (digits == null)
            return -1;
        return date2int(digits[0], digits[1], digits[2]);
    }

    static public Date getDate(String dateStr) {
        return DateUtility.int2date(DateUtility.date2int(dateStr));
    }

    /**
     * 将一个格式为"hh:mm:ss"的时间字符串转换成一个时间整数
     *
     * @param timeStr
     * @return
     */
    static public int time2int(String timeStr) {
        int[] digits = parse(timeStr);
        if (digits == null)
            return 0;
        return digits[3] * 3600 + digits[4] * 60 + digits[5];
    }

    /**
     * 将一个格式为"hh:mm:ss"的时间字符串转换成一个时间整数
     *
     * @param time
     * @return
     */
    static public int time2int(Date time) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(time);
        return time2int(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND));
    }

    static public int time2int(int hour, int minute, int second) {
        return hour * 3600 + minute * 60 + second;
    }

    static public int now() {
        Calendar cal = Calendar.getInstance();
        return date2int(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DATE));
    }

    static public long nowdatetime() {
        Calendar cal = Calendar.getInstance();
        long ndate = date2int(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DATE));
        long ntime = time2int(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND));
        return ndate * SECONDS_PERDAY + ntime;
    }

    /**
     * 把Julian日期转换成普通日期
     */
    static public Date int2date(int ndate) {
        int[] datearr = int2datearr(ndate);
        Calendar cal = Calendar.getInstance();
        cal.set(datearr[0], datearr[1] - 1, datearr[2], 0, 0, 0);
        return cal.getTime();
    }

    /**
     * 将一个整数日期转换成一个datearr, 维度为3， 分别是年月日
     *
     * @param ndate
     * @param datearr
     */
    public static void int2date(int ndate, int[] datearr) {
        int a = ndate + 32044;
        int b = ((a << 2) + 3) / 146097;
        int c = a - ((b * 146097) >> 2);

        int d = ((c << 2) + 3) / 1461;
        int e = c - ((1461 * d) >> 2);
        int m = (5 * e + 2) / 153;

        datearr[0] = b * 100 + d - 4800 + m / 10;
        datearr[1] = m + 3 - 12 * (m / 10);
        datearr[2] = e - (153 * m + 2) / 5 + 1;
    }

    static public Date long2datetime(long ndatetime) {
        int[] datearr = int2datearr((int) (ndatetime / SECONDS_PERDAY));
        int ntime = (int) (ndatetime % SECONDS_PERDAY);
        Calendar cal = Calendar.getInstance();
        cal.set(datearr[0], datearr[1] - 1, datearr[2], ntime / 3600, (ntime % 3600) / 60, ntime % 60);
        return cal.getTime();
    }

    /**
     * 将一个整数日期转换成一个datearr, 维度为3， 分别是年月日
     *
     * @param ndate
     */
    public static int[] int2datearr(int ndate) {
        int a = ndate + 32044;
        int b = ((a << 2) + 3) / 146097;
        int c = a - ((b * 146097) >> 2);

        int d = ((c << 2) + 3) / 1461;
        int e = c - ((1461 * d) >> 2);
        int m = (5 * e + 2) / 153;

        return new int[]{
                b * 100 + d - 4800 + m / 10, // year
                m + 3 - 12 * (m / 10), // month
                e - (153 * m + 2) / 5 + 1 // day
        };
    }

    /**
     * 返回年
     */
    public static int getYear(int ndate) {
        int a = ndate + 32044;
        int b = ((a << 2) + 3) / 146097;
        int c = a - ((b * 146097) >> 2);

        int d = ((c << 2) + 3) / 1461;
        int e = c - ((1461 * d) >> 2);
        int m = (5 * e + 2) / 153;
        return b * 100 + d - 4800 + m / 10;
    }

    /**
     * 返回月份
     */
    public static int getMonth(int ndate) {
        int a = ndate + 32044;
        int b = ((a << 2) + 3) / 146097;
        int c = a - ((b * 146097) >> 2);

        int d = ((c << 2) + 3) / 1461;
        int e = c - ((1461 * d) >> 2);
        int m = (5 * e + 2) / 153;
        return m + 3 - 12 * (m / 10);
    }

    /**
     * 返回多少号
     */
    public static int getDayOfMonth(int ndate) {
        int a = ndate + 32044;
        int b = ((a << 2) + 3) / 146097;
        int c = a - ((b * 146097) >> 2);

        int d = ((c << 2) + 3) / 1461;
        int e = c - ((1461 * d) >> 2);
        int m = (5 * e + 2) / 153;
        return e - (153 * m + 2) / 5 + 1;
    }

    /**
     * 将一个整数日期格式为"YYYY-MM-DD"的日期字符串
     */
    static public String int2datestr(int ndate) {
        int[] datearr = int2datearr(ndate);
        return formatDate(datearr[0], datearr[1], datearr[2]);
    }

    /**
     * 将一个时间整数格式化为"hh:mm:ss"格式输出
     */
    static public String int2timestr(int ntime) {
        ntime = ntime % SECONDS_PERDAY;
        int h = ntime / 3600;
        int m = (ntime % 3600) / 60;
        int s = ntime % 60;
        return formatTime(h, m, s);
    }

    static public String formatDate(int year, int month, int day) {
        StringBuilder sb = new StringBuilder();
        sb.append(year);
        sb.append('-');
        if (month < 10)
            sb.append('0');
        sb.append(month).append('-');
        if (day < 10)
            sb.append('0');
        sb.append(day);
        return sb.toString();
    }

    static public String formatDate(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return formatDate(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DATE));
    }

    static public String formatTime(int hour, int minute, int second) {
        StringBuilder sb = new StringBuilder();
        if (hour < 10)
            sb.append('0');
        sb.append(hour).append(':');
        if (minute < 10)
            sb.append('0');
        sb.append(minute).append(':');
        if (second < 10)
            sb.append('0');
        sb.append(second);
        return sb.toString();
    }

    static public String formatTime(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return formatTime(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND));
    }

    static public String formatDateTime(int year, int month, int day, int hour, int minute, int second) {
        StringBuilder sb = new StringBuilder();
        sb.append(year);
        sb.append('-');
        if (month < 10)
            sb.append('0');
        sb.append(month).append('-');
        if (day < 10)
            sb.append('0');
        sb.append(day);
        sb.append(' ');
        if (hour < 10)
            sb.append('0');
        sb.append(hour).append(':');
        if (minute < 10)
            sb.append('0');
        sb.append(minute).append(':');
        if (second < 10)
            sb.append('0');
        sb.append(second);
        return sb.toString();
    }

    static public String formatDateTime(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return formatDateTime(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DATE),
                cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND));
    }


    /**
     * 将一个格式为"YYYY-MM-DD hh:mm:ss"的时间字符串转换成一个日期时间长整数
     *
     * @param datetimeStr
     * @return
     */
    static public long datetime2long(String datetimeStr) {
        if (datetimeStr == null || datetimeStr.length() == 0)
            return -1L;

        int[] digits = parse(datetimeStr);
        if (digits == null)
            return -1;
        int ndate = date2int(digits[0], digits[1], digits[2]);
        int ntime = digits[3] * 3600 + digits[4] * 60 + digits[5];
        return (long) ndate * SECONDS_PERDAY + (long) ntime;
    }

    static public long datetime2long(Date datetime) {
        if (datetime == null)
            return 0L;

        Calendar cal = Calendar.getInstance();
        cal.setTime(datetime);
        long ndate = date2int(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DATE));
        long ntime = time2int(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND));
        return ndate * SECONDS_PERDAY + ntime;
    }

    /**
     * 将一个日期时间长整数格式为"YYYY-MM-DD hh:mm:ss"的时间字符串
     *
     * @param ndatetime
     * @return
     */
    static public String long2datetimestr(long ndatetime) {
        if (ndatetime != -1)
            return int2datestr((int) (ndatetime / SECONDS_PERDAY)) + ' ' + int2timestr((int) (ndatetime % SECONDS_PERDAY));
        else
            return "";
    }

    /**
     * 根据指定日期的星期数(1 表示周一, 2表示周二,以此类推)
     */
    static public int getDayOfWeek(int ndate) {
        return ndate % 7 + 1;
    }

    /**
     * 返回本日在当年的星期数（星期天在这里算一个星期的最后一天）
     */
    static public int getWeekOfYear(int jd) {
        int d4 = (jd + 31741 - (jd % 7)) % 146097 % 36524 % 1461;
        int L = d4 / 1460;
        return (((d4 - L) % 365) + L) / 7 + 1;
    }

    /**
     * 返回本日在当月的星期数
     */
    static public int getWeekOfMonth(int jd) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(int2date(jd));
        return getWeekOfYear(jd) - getWeekOfYear(date2int(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), 1)) + 1;
    }

    /**
     * 返回本月的第一天
     */
    static public int getFirstDayOfMonth(int ndate) {
        int[] datearr = int2datearr(ndate);
        return date2int(datearr[0], datearr[1], 1);
    }

    /**
     * 返回本月的最后一天
     */
    static public int getLastDayOfMonth(int ndate) {
        int[] datearr = int2datearr(ndate);

        datearr[2] = 1;
        if (datearr[1] == 12) {
            datearr[0]++;
            datearr[1] = 1;
        } else {
            datearr[1]++;
        }
        return date2int(datearr[0], datearr[1], datearr[2]) - 1;
    }

    /**
     * 返回本月的天数
     */
    static public int getDayCountOfMonth(int ndate) {
        return getLastDayOfMonth(ndate) - getFirstDayOfMonth(ndate) + 1;
    }

    private static int section2Int(char[] chrs, int start, int end) {
        int result = 0;
        for (int i = start; i <= end; i++) {
            if (chrs[i] >= '0' && chrs[i] <= '9')
                result = result * 10 + (chrs[i] - '0');
            else
                break;
        }
        return result;
    }

    public static int[] parse(String datetime) {
        datetime = datetime != null ? datetime.trim() : null;
        if (datetime == null || datetime.isEmpty())
            return null;

        int dc = 0, tc = 0;
        boolean fordate = false, fortime = false;
        int[] digits = new int[6];
        char[] chs = datetime.toCharArray();
        int lastpos = 0;

        for (int i = 0; i < 6; i++)
            digits[i] = 0;

        for (int i = 0; ; i++) {
            if (i >= chs.length || chs[i] == ' ') {
                if (fordate && dc < 3) {
                    digits[dc++] = section2Int(chs, lastpos, i - 1);
                } else if (fortime && tc < 3) {
                    digits[3 + (tc++)] = section2Int(chs, lastpos, i - 1);
                }
                lastpos = i + 1;

                if (i >= chs.length)
                    break;
            } else if (chs[i] == '-' && dc < 3) {
                fordate = true;
                fortime = false;
                digits[dc++] = section2Int(chs, lastpos, i - 1);
                lastpos = i + 1;
            } else if (chs[i] == ':' && tc < 3) {
                fordate = false;
                fortime = true;
                digits[3 + (tc++)] = section2Int(chs, lastpos, i - 1);
                lastpos = i + 1;
            }
        }
        if (digits[1] == 0)
            digits[1] = 1;
        if (digits[2] == 0)
            digits[2] = 1;
        return digits;
    }

    /**
     * 判断当前时间是否工作日
     *
     * @return 是工作日返回true, 不是返回false
     * @deprecated 用isWorkDayTime()方法替代，isWorkDayTime 考虑了节假日
     */
    public static Boolean checkNowIsWorkTime() {
        Date dt = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(dt);
        // 当前小时
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        // 当前分钟
        int minute = cal.get(Calendar.MINUTE);
        // 星期
        int week = cal.get(Calendar.DAY_OF_WEEK) - 1;

        // 判断星期在一到五之间
        if (week >= 1 && week <= 5) {
            // 判断时间在早上9:30到晚上18:30之间
            if (hour > 8 && hour < 19) {
                if (hour == 9 && minute >= 30) {
                    return true;
                } else if (hour == 18 && minute <= 30) {
                    return true;
                } else
                    return hour > 9 || hour < 18;
            }
        }
        return false;
    }

    /**
     * 将长时间格式字符串yyyy-MM-dd HH:mm:ss转换为时间
     *
     * @param strDate
     * @return
     */
    public static Date parseStringToDate(String strDate) {
        return DateUtility.long2datetime(DateUtility.datetime2long(strDate));
    }

    /*
     *  当前日期增加days
     */
    public static Date getNextDate(int days) {
        return long2datetime(nowdatetime() + (long) days * SECONDS_PERDAY);
    }

    /**
     * 当前时间后30分钟时间 返回格式 如：13:15
     *
     * @return
     */
    public static String getNext30MinTime() {
        return int2timestr((int) ((nowdatetime() + 30 * 60) % SECONDS_PERDAY)).substring(0, 5);
    }
}
