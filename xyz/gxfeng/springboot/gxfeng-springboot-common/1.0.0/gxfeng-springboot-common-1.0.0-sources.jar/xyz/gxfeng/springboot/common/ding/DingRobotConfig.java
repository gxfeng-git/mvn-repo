package xyz.gxfeng.springboot.common.ding;

import lombok.Data;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description
 * @date 2022/3/30
 */
@Data
@Configuration
@ConditionalOnProperty(value = {"accessToken"}, prefix = "ding.robot")
@ConfigurationProperties(prefix = "ding.robot")
public class DingRobotConfig {

    private String accessToken;

    private String secret;

    private String keyword;
}
