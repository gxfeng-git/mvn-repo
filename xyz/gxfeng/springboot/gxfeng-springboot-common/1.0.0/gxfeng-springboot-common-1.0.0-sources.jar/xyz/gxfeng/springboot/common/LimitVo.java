package xyz.gxfeng.springboot.common;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import org.springframework.util.Assert;

@Getter
public abstract class LimitVo<T> {

    /**
     * 当前页数
     */
    @ApiModelProperty(value = "当前页数", example = "1")
    private Integer pageNum = 1;

    /**
     * 显示条数
     */
    @ApiModelProperty(value = "显示条数", example = "10")
    private Integer pageSize = 10;

    @ApiModelProperty(hidden = true)
    public IPage<T> getPage() {
        return Page.of(this.pageNum, this.pageSize);
    }

    public void setPageNum(Integer pageNum) {
        Assert.isTrue(pageNum % 1 == 0, "页数必须是整数");
        if (pageNum < 1) {
            pageNum = 1;
        }
        this.pageNum = pageNum;
    }

    public void setPageSize(Integer pageSize) {
        Assert.isTrue(pageSize % 1 == 0, "显示条数必须是整数");
        if (pageSize < 10) {
            pageSize = 10;
        }
        if (pageSize > 200) {
            pageSize = 200;
        }
        this.pageSize = pageSize;
    }
}
