package xyz.gxfeng.springboot.common;

import java.lang.annotation.*;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description 不进行body序列化
 * @date 2022/10/21
 */
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface UnBodyAdvice {
}
