package xyz.gxfeng.springboot.common.ding;

import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import xyz.gxfeng.springboot.common.util.DateUtil;
import xyz.gxfeng.springboot.common.util.RestTemplateUtils;

import javax.annotation.PostConstruct;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description
 * @date 2022/3/30
 */
@Slf4j
@Component
public class DingRobotUtil {

    private static final String ROBOT_HOST = "https://oapi.dingtalk.com/robot/send?access_token=";
    private static String ACCESS_TOKEN;
    private static String SECRET;
    private static String KEYWORD;

    private static String ENV = "unknow";
    private static String PROJECT = "unknow";

    @Autowired(required = false)
    private DingRobotConfig dingRobotConfig;
    @Autowired(required = false)
    private Environment environment;

    public static void sendMsg(String contentMsg) {
        sendMsg(contentMsg, AtEnum.ALL);
    }

    public static void sendMsg(String contentMsg, AtEnum atEnum, String... list) {
        try {
            JSONObject body = new JSONObject();
            String url = ROBOT_HOST + ACCESS_TOKEN;
            if (StringUtils.isBlank(ACCESS_TOKEN)) {
                throw new RuntimeException("access_token不能为空");
            }
            if (StringUtils.isNotBlank(KEYWORD)) {
                contentMsg = " \n #### 【关键词】" + KEYWORD + " \n #### 【消息】 \n > " + contentMsg;
            } else {
                contentMsg = " \n #### 【消息】 \n > " + contentMsg;
            }
            if (StringUtils.isNotBlank(SECRET)) {
                Long timestamp = System.currentTimeMillis();
                String stringToSign = timestamp + "\n" + SECRET;
                Mac mac = Mac.getInstance("HmacSHA256");
                mac.init(new SecretKeySpec(SECRET.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
                byte[] signData = mac.doFinal(stringToSign.getBytes(StandardCharsets.UTF_8));
                String sign = URLEncoder.encode(new String(Base64.encodeBase64(signData)), "UTF-8");
                url += "&timestamp=" + timestamp + "&sign=" + sign;
            }
            JSONObject at = new JSONObject();
            switch (atEnum) {
                case ALL:
                    at.put("isAtAll", "true");
                    contentMsg = " \n #### 【消息接收人】 <font color=#498FF7>@所有人 </font> \n > " + contentMsg;
                    break;
                case MOBILES:
                    Assert.isTrue(list != null, "@不能为空");
                    String join = StringUtils.join(list, " @");
                    contentMsg = " \n #### 【消息接收人】 <font color=#498FF7>@" + join + " </font> \n > " + contentMsg;
                    at.put("atMobiles", Arrays.asList(list));
                    break;
                case USERIDS:
                    Assert.isTrue(list != null, "@不能为空");
                    join = StringUtils.join(list, " @");
                    contentMsg = " \n #### 【消息接收人】 <font color=#498FF7>@" + join + " </font> \n > " + contentMsg;
                    at.put("atUserIds", Arrays.asList(list));
                    break;
                default:
            }
            body.put("at", at);
            body.put("msgtype", "markdown");
            JSONObject markdown = new JSONObject();
            markdown.put("title", PROJECT + "项目" + ENV + "环境");
            markdown.put("text", "## " + PROJECT + "项目" + ENV + "环境 \n #### 【时间】" + DateUtil.getTime() + contentMsg);
            body.put("markdown", markdown);
            log.info("发送钉钉机器人信息地址开始，参数: {}，发送信息数据: {}", url, body);
            String res = RestTemplateUtils.post(url, body, String.class);
            log.info("发送钉钉机器人信息地址结束，响应：{}", res);
        } catch (Exception e) {
            log.error("发送钉钉机器人信息异常: ", e);
        }
    }

    @PostConstruct
    private void init() {
        if (environment != null) {
            ENV = environment.getProperty("spring.profiles.active", "unknow");
            PROJECT = environment.getProperty("spring.application.name", "unknow");
        }
        if (null != dingRobotConfig) {
            ACCESS_TOKEN = dingRobotConfig.getAccessToken();
            SECRET = dingRobotConfig.getSecret();
            KEYWORD = dingRobotConfig.getKeyword();
        }
    }

    public enum AtEnum {
        ALL,
        MOBILES,
        USERIDS
    }
}
