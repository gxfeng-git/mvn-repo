package xyz.gxfeng.springboot.common;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import xyz.gxfeng.springboot.common.exception.AuthException;
import xyz.gxfeng.springboot.common.exception.BusinessException;
import xyz.gxfeng.springboot.common.exception.NotFoundException;

import javax.validation.ConstraintViolationException;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description 全局异常处理
 * @date 2021/12/14
 */
@Slf4j
@RestControllerAdvice
public class WebRestControllerAdvice {

    @ExceptionHandler({HttpMessageNotReadableException.class, HttpRequestMethodNotSupportedException.class, ConstraintViolationException.class, MethodArgumentNotValidException.class, IllegalArgumentException.class, MissingServletRequestParameterException.class, BindException.class, NotFoundException.class, AuthException.class, BusinessException.class, RuntimeException.class, Exception.class})
    public Result<String> exception(Exception ex) {
        return Result.error(ex);
    }
}
