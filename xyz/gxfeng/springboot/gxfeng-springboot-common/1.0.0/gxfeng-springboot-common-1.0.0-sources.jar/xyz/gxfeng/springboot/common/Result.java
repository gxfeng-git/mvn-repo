package xyz.gxfeng.springboot.common;

import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import xyz.gxfeng.springboot.common.exception.AuthException;
import xyz.gxfeng.springboot.common.exception.BusinessException;
import xyz.gxfeng.springboot.common.exception.NotFoundException;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description 统一响应体
 * @date 2021/12/14
 */
@Slf4j
@Setter
@Getter
@ToString
public class Result<T> {

    public static final String X_GXFENG_REQUEST_ID = "X-Gxfeng-Request-Id";
    protected static final String DEFAULT_SUCCESS_MESSAGE = "操作成功";
    private static final int REQUEST_ID_LENGTH = 32;
    @JsonIgnore
    protected HttpStatus status;
    protected String requestId;
    protected String code;
    protected T data;
    protected String message;
    protected Date timestamp = new Date();

    protected Result() {

    }

    protected Result(HttpStatus status, String requestId, String code, T data, String message) {
        this.status = status;
        this.requestId = requestId;
        this.code = code;
        this.data = data;
        this.message = message;
        this.timestamp = timestamp;
    }

    protected Result(HttpStatus status, String requestId, String code, T data, String message, Date timestamp) {
        this.status = status;
        this.requestId = requestId;
        this.code = code;
        this.data = data;
        this.message = message;
        this.timestamp = timestamp;
    }

    public static <M> Result<M> success(String code, Run<? extends M> data) {
        return result(HttpStatus.OK, code, DEFAULT_SUCCESS_MESSAGE, data);
    }

    public static <M> Result<M> success(Run<? extends M> data) {
        return result(HttpStatus.OK, String.valueOf(HttpStatus.OK.value()), DEFAULT_SUCCESS_MESSAGE, data);
    }

    public static <M> Result<M> success() {
        return success(null);
    }

    public static <M> Result<M> error(HttpStatus httpStatus, String code, String message) {
        if (null == httpStatus) {
            httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        }
        return result(httpStatus, code, message, null);
    }

    public static <M> Result<M> error(HttpStatus httpStatus, String message) {
        return error(httpStatus, String.valueOf(httpStatus.value()), message);
    }

    public static <M> Result<M> error(Exception e) {
        return error(e, true);
    }

    public static <M> Result<M> error(Exception e, boolean printLog) {
        HttpStatus status = null;
        String msg = StringUtils.defaultIfBlank(e.getMessage(), "服务异常");
        String error = "其他异常";
        if (e instanceof HttpMessageNotReadableException) {
            error = "参数转换异常";
            status = HttpStatus.BAD_REQUEST;
        } else if (e instanceof HttpRequestMethodNotSupportedException) {
            error = "请求方式异常";
            status = HttpStatus.METHOD_NOT_ALLOWED;
            msg = "不支持" + ((HttpRequestMethodNotSupportedException) e).getMethod() + "请求方式";
        } else if (e instanceof ConstraintViolationException) {
            error = "方法参数校验异常";
            status = HttpStatus.BAD_REQUEST;
            StringBuffer sb = new StringBuffer();
            Set<ConstraintViolation<?>> constraintViolations = ((ConstraintViolationException) e).getConstraintViolations();
            if (CollectionUtils.isNotEmpty(constraintViolations)) {
                for (ConstraintViolation constraintViolation : constraintViolations) {
                    sb.append(constraintViolation.getMessage());
                }
            }
            msg = sb.toString();
        } else if (e instanceof MethodArgumentNotValidException) {
            error = "方法参数校验异常";
            status = HttpStatus.BAD_REQUEST;
            if (((MethodArgumentNotValidException) e).getBindingResult() != null) {
                StringBuilder sb = new StringBuilder();
                List<ObjectError> allErrors = ((MethodArgumentNotValidException) e).getBindingResult().getAllErrors();
                allErrors.stream().filter(Objects::nonNull).forEach(objectError -> {
                    sb.append("[").append(((FieldError) objectError).getField()).append(": ").append(objectError.getDefaultMessage()).append("]");
                });
                msg = sb.toString();
            }
        } else if (e instanceof IllegalArgumentException) {
            error = "参数异常,异常信息:";
            status = HttpStatus.BAD_REQUEST;
        } else if (e instanceof MissingServletRequestParameterException) {
            error = "缺少参数异常";
            status = HttpStatus.BAD_REQUEST;
        } else if (e instanceof BindException) {
            error = "方法参数绑定异常";
            status = HttpStatus.BAD_REQUEST;
            if (((BindException) e).getBindingResult() != null) {
                StringBuilder sb = new StringBuilder();
                List<ObjectError> allErrors = ((BindException) e).getBindingResult().getAllErrors();
                allErrors.stream().filter(Objects::nonNull).forEach(objectError -> {
                    sb.append("[").append(((FieldError) objectError).getField()).append(": ").append(objectError.getDefaultMessage()).append("]");
                });
                msg = sb.toString();
            }
        } else if (e instanceof NotFoundException) {
            error = "notfound异常";
            status = NotFoundException.status;
        } else if (e instanceof AuthException) {
            error = "auth认证异常";
            if (printLog) {
                log.error(error, e);
            }
            return result(AuthException.status, AuthException.code, msg, null);
        } else if (e instanceof BusinessException) {
            error = "业务异常";
            if (printLog) {
                log.error(error, e);
            }
            return (Result<M>) result(BusinessException.status, ((BusinessException) e).getCode(), msg, ((BusinessException) e)::getData);
        } else {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
        }
        if (printLog) {
            log.error(error, e);
        }
        return error(status, msg);
    }

    public static <M> Result<M> result(HttpStatus httpStatus, String code, String message, Run<? extends M> data) {
        Result<M> result = new Result<>();
        result.setStatus(httpStatus);
        result.setCode(code);
        if (null != data) {
            result.setData(data.get());
        }
        result.setMessage(message);
        return setRequestId(result, null);
    }

    public static <T> Result<T> setRequestId(Result<T> body, ServerHttpRequest request) {
        String requestId = null;
        if (null == request) {
            ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (null != requestAttributes) {
                request = new ServletServerHttpRequest(requestAttributes.getRequest());
            }
        }
        if (null != request && request.getHeaders().containsKey(X_GXFENG_REQUEST_ID)) {
            requestId = request.getHeaders().getFirst(X_GXFENG_REQUEST_ID);
        }
        if (StringUtils.isBlank(requestId) || REQUEST_ID_LENGTH != requestId.length()) {
            requestId = IdWorker.get32UUID();
        }
        if (null == body) {
            body = Result.success();
        } else {
            body.setRequestId(requestId);
        }
        return body;
    }

    public interface Run<S> {
        S exec();

        default S get() {
            return exec();
        }
    }
}
