package xyz.gxfeng.springboot.common.exception;

import lombok.Getter;
import lombok.ToString;
import org.springframework.http.HttpStatus;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description 自定义异常类，用来处理业务
 * @date 2021/12/14
 */
@Getter
@ToString
public class BusinessException extends Exception {

    public static final HttpStatus status = HttpStatus.OK;
    private static final String ERROR_MSG = "业务异常！";
    private static final String WARNING_CODE = "-1";

    private final String code;
    private Object data;

    public BusinessException() {
        super(ERROR_MSG);
        this.code = WARNING_CODE;
    }

    public BusinessException(String msg) {
        super(msg);
        this.code = WARNING_CODE;
    }

    public BusinessException(String msg, Object data) {
        super(msg);
        this.code = WARNING_CODE;
        this.data = data;
    }

    public BusinessException(String code, String msg) {
        super(msg);
        this.code = code;
    }

    public BusinessException(String code, String msg, Object data) {
        super(msg);
        this.code = code;
        this.data = data;
    }
}
