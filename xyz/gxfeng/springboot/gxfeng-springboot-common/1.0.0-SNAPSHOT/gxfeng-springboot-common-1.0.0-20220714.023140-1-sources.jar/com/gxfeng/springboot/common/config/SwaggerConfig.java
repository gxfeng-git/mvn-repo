package com.gxfeng.springboot.common.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2WebMvc;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description
 * @date 2021/12/14
 */
@Configuration
@ConditionalOnProperty(prefix = "swagger", name = "enabled", havingValue = "true")
@EnableSwagger2WebMvc
public class SwaggerConfig {

    @Value("${swagger.enabled:}")
    private Boolean enabled;
    @Value("${swagger.host:}")
    private String host;
    @Value("${swagger.version:1.0.0}")
    private String version;
    @Value("${swagger.package:com.gxfeng.springboot.common.controller}")
    private String basePackage;
    @Value("${swagger.description:}")
    private String description;
    @Value("${swagger.title:}")
    private String title;

    @Bean
    public Docket docket() {
        Docket docket = new Docket(DocumentationType.SWAGGER_2);
        docket.host(host);
        docket.apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage(basePackage))
                .paths(PathSelectors.any())
                .build();
        return docket;
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title(title)
                .description(description)
                .version(version)
                .build();
    }
}
