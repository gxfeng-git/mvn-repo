package com.gxfeng.springboot.common.entity;

import lombok.Data;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description
 * @date 2022/6/28
 */
@Data
public class PropertyModelInfoEntity {
    /**
     * 属性名称
     */
    private String propertyName;
    /**
     * 属性注释
     */
    private String propertyComment;
    /**
     * 属性值
     */
    private Object value;
    /**
     * 返回值类型
     */
    private Class<?> returnType;
}
