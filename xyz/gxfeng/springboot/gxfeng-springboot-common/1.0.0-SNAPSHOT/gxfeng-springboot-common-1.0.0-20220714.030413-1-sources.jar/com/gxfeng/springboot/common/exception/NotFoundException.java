package com.gxfeng.springboot.common.exception;

import lombok.Getter;
import lombok.ToString;
import org.springframework.http.HttpStatus;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description
 * @date 2021/12/14
 */
@Getter
@ToString
public class NotFoundException extends Exception {

    public static final HttpStatus status = HttpStatus.NOT_FOUND;
    private String uri;
    private String date;

    private NotFoundException() {
    }

    private NotFoundException(String message, String uri, String date) {
        super(message);
        this.uri = uri;
        this.date = date;
    }

    public NotFoundException(String uri, String date) {
        this(date.concat(" 访问资源不存在, uri: ").concat(uri), uri, date);
    }
}
