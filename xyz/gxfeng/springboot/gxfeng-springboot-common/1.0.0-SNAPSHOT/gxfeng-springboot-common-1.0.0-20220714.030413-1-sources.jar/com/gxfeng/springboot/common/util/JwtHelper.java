package com.gxfeng.springboot.common.util;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.gxfeng.springboot.common.exception.AuthException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Date;
import java.util.function.Function;

/**
 * @author gxfeng
 * @Description: token 工具类
 * @date 2020/9/8
 * <p>
 * <p>
 * 注意jwt只是对相关信息进行了base64,所以可以在jwt.io官网或者其他网站解析
 * payload里面应该剔除敏感信息
 * </p>
 */
@Component
public class JwtHelper {

    // 签名信息 不能泄露 否则可能会被伪造token
    private static String SEC = "token.secret";
    // 过期时间单位毫秒
    private static long EXP = 60 * 1000 * 60 * 24 * 7;

    @Autowired(required = false)
    private Environment env;

    public static String generateToken(String id) {
        long nowMillis = System.currentTimeMillis();
        return JWT.create()
                // 签发时间
                .withIssuedAt(new Date(nowMillis))
                // 过期时间
                .withExpiresAt(new Date(nowMillis + EXP))
                .withSubject(id)
                // 签名信息
                .sign(Algorithm.HMAC512(SEC));
    }

    public static DecodedJWT getDecodedJWTmFromToken(String token) throws AuthException {
        try {
            return JWT
                    .require(Algorithm.HMAC512(SEC))
                    .build()
                    .verify(token);
        } catch (Exception e) {
            throw new AuthException(e.getMessage());
        }
    }

    public static <T> T getFromToken(String token, Function<DecodedJWT, T> function) throws AuthException {
        try {
            DecodedJWT decodedJWT = getDecodedJWTmFromToken(token);
            return function.apply(decodedJWT);
        } catch (Exception e) {
            throw new AuthException(e.getMessage());
        }
    }

    public static Date getIssuedAtDateFromToken(String token) throws AuthException {
        return getFromToken(token, DecodedJWT::getIssuedAt);
    }

    public static Date getExpiresAtDateFromToken(String token) throws AuthException {
        return getFromToken(token, DecodedJWT::getExpiresAt);
    }

    private static Boolean isTokenExpired(String token) throws AuthException {
        final Date expiresAt = getExpiresAtDateFromToken(token);
        return expiresAt.before(new Date());
    }

    private static Boolean isCreatedBeforeLastPasswordReset(Date created, Date lastPasswordReset) {
        return (lastPasswordReset != null && !lastPasswordReset.equals("") && created.before(lastPasswordReset));
    }

    public static String getUserIdFromToken(String token) throws AuthException {
        return getFromToken(token, DecodedJWT::getSubject);
    }

    public static String getParkIdFromToken(String token) throws AuthException {
        return getFromToken(token, DecodedJWT::getIssuer);
    }

    public static boolean validateToken(String token, Date lastPassWordResetDate) throws AuthException {
        final Date created = getIssuedAtDateFromToken(token);
        // 如果token存在，且token创建日期 > 最后修改密码的日期 则代表token有效
        return !isTokenExpired(token) && !isCreatedBeforeLastPasswordReset(created, lastPassWordResetDate);
    }

    @PostConstruct
    public void init() {
        if (env != null) {
            String secret = env.getProperty("jwt.auth.secret");
            if (StringUtils.isNotBlank(secret)) {
                SEC = secret;
            } else {
                SEC = "token.secret";
            }
            Long expire = env.getProperty("jwt.auth.expire", Long.class);
            if (expire != null) {
                EXP = expire;
            } else {
                EXP = 60 * 1000 * 60 * 24 * 7;
            }
        }
    }
}
