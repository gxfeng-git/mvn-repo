package com.gxfeng.springboot.common.redis;

import org.apache.commons.lang3.StringUtils;
import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RedissonClientConfig {

    @Autowired(required = false)
    private RedisProperties redisProperties;

    @Bean
    @ConditionalOnBean(value = {RedisConfig.class, RedisProperties.class})
    public RedissonClient redissonClient() {
        String url = "";
        if (StringUtils.isNotBlank(redisProperties.getUrl())) {
            url = redisProperties.getUrl();
        } else {
            url = "redis://".concat(redisProperties.getHost()).concat(":" + redisProperties.getPort());
        }
        Config config = new Config();
        config.useSingleServer().setAddress(url)
                .setPassword(redisProperties.getPassword())
                .setDatabase(redisProperties.getDatabase())
                .setConnectionMinimumIdleSize(2)
                .setConnectionPoolSize(8)
                .setPingConnectionInterval(60000);
        return Redisson.create(config);
    }
}
