package com.gxfeng.springboot.common;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gxfeng.springboot.common.exception.AuthException;
import com.gxfeng.springboot.common.exception.BusinessException;
import com.gxfeng.springboot.common.exception.NotFoundException;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;

import javax.validation.ConstraintViolationException;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description 统一响应体
 * @date 2021/12/14
 */
@Slf4j
@Setter
@Getter
@ToString
public class Result<T> {

    private static final String DEFAULT_SUCCESS_MESSAGE = "操作成功";

    @JsonIgnore
    private HttpStatus status;
    private String requestId;
    private String code;
    private T data;
    private String message;
    private Date timestamp = new Date();

    public static <M> Result<M> result(HttpStatus httpStatus, String code, String message, Run<? extends M> data) {
        Result<M> result = new Result<>();
        result.setStatus(httpStatus);
        result.setCode(code);
        if (null != data) {
            result.setData(data.get());
        }
        result.setMessage(message);
        return result;
    }

    public static <M> Result<M> success(String code, Run<? extends M> data) {
        return result(HttpStatus.OK, code, DEFAULT_SUCCESS_MESSAGE, data);
    }

    public static <M> Result<M> success(Run<? extends M> data) {
        return result(HttpStatus.OK, String.valueOf(HttpStatus.OK.value()), DEFAULT_SUCCESS_MESSAGE, data);
    }

    public static <M> Result<M> success() {
        return success(null);
    }

    public static <M> Result<M> error(HttpStatus httpStatus, String code, String message) {
        if (null == httpStatus) {
            httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        }
        return result(httpStatus, code, message, null);
    }

    public static <M> Result<M> error(HttpStatus httpStatus, String message) {
        return error(httpStatus, String.valueOf(httpStatus.value()), message);
    }

    public static <M> Result<M> error(Exception e) {
        HttpStatus status = null;
        String msg = e.getMessage();
        if (e instanceof HttpMessageNotReadableException) {
            log.error("参数转换异常", e);
            status = HttpStatus.BAD_REQUEST;
        } else if (e instanceof HttpRequestMethodNotSupportedException) {
            log.error("请求方式异常", e);
            status = HttpStatus.METHOD_NOT_ALLOWED;
            msg = "不支持" + ((HttpRequestMethodNotSupportedException) e).getMethod() + "请求方式";
        } else if (e instanceof ConstraintViolationException) {
            log.error("方法参数校验异常", e);
            status = HttpStatus.BAD_REQUEST;
        } else if (e instanceof MethodArgumentNotValidException) {
            log.error("方法参数校验异常", e);
            status = HttpStatus.BAD_REQUEST;
            if (((MethodArgumentNotValidException) e).getBindingResult() != null) {
                StringBuilder sb = new StringBuilder("");
                List<ObjectError> allErrors = ((MethodArgumentNotValidException) e).getBindingResult().getAllErrors();
                allErrors.stream().filter(Objects::nonNull).forEach(objectError -> {
                    sb.append("[").append(((FieldError) objectError).getField()).append(": ").append(objectError.getDefaultMessage()).append("]");
                });
                msg = sb.toString();
            }
        } else if (e instanceof IllegalArgumentException) {
            log.error("参数异常,异常信息:", e);
            status = HttpStatus.BAD_REQUEST;
        } else if (e instanceof MissingServletRequestParameterException) {
            log.error("缺少参数异常", e);
            status = HttpStatus.BAD_REQUEST;
        } else if (e instanceof BindException) {
            log.error("方法参数绑定异常", e);
            status = HttpStatus.BAD_REQUEST;
            if (((BindException) e).getBindingResult() != null) {
                StringBuilder sb = new StringBuilder("");
                List<ObjectError> allErrors = ((BindException) e).getBindingResult().getAllErrors();
                allErrors.stream().filter(Objects::nonNull).forEach(objectError -> {
                    sb.append("[").append(((FieldError) objectError).getField()).append(": ").append(objectError.getDefaultMessage()).append("]");
                });
                msg = sb.toString();
            }
        } else if (e instanceof NotFoundException) {
            log.error("notfound异常", e);
            status = NotFoundException.status;
        } else if (e instanceof AuthException) {
            log.error("auth认证异常", e);
            return result(AuthException.status, AuthException.code, msg, null);
        } else if (e instanceof BusinessException) {
            log.error("业务异常", e);
            return (Result<M>) result(BusinessException.status, ((BusinessException) e).getCode(), msg, ((BusinessException) e)::getData);
        } else {
            log.error("其他异常", e);
            status = HttpStatus.INTERNAL_SERVER_ERROR;
        }
        return error(status, msg);
    }

    public interface Run<S> {
        S exec();

        default S get() {
            return exec();
        }
    }
}
