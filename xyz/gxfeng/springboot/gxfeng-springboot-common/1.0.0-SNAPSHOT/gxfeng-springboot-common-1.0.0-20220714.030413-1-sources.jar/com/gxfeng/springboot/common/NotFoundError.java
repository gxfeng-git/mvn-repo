package com.gxfeng.springboot.common;

import com.gxfeng.springboot.common.exception.NotFoundException;
import com.gxfeng.springboot.common.util.DateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.ErrorProperties;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.boot.autoconfigure.web.servlet.error.AbstractErrorController;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.Map;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description error
 * @date 2021/12/14
 */
@Controller
@RequestMapping("${server.error.path:${error.path:/error}}")
public class NotFoundError extends AbstractErrorController {

    private ErrorProperties errorProperties;

    @Autowired
    public NotFoundError(ErrorAttributes errorAttributes, ServerProperties serverProperties) {
        super(errorAttributes);
        this.errorProperties = serverProperties.getError();
    }

    private ErrorProperties getErrorProperties() {
        return this.errorProperties;
    }

    @Override
    public String getErrorPath() {
        return this.errorProperties.getPath();
    }

    @RequestMapping
    @ResponseBody
    public Result<String> error(HttpServletRequest request) {
        Map<String, Object> errorMap = getErrorAttributes(request, false);
        String uri = (String) errorMap.get("path");
        String date = DateUtil.format((Date) errorMap.get("timestamp"), DateUtil.YYYY_MM_DD_HH_MM_SS);
        return Result.error(new NotFoundException(uri, date));
    }
}
