package com.gxfeng.springboot.common;

import com.gxfeng.springboot.common.annotation.UnBodyAdvice;
import com.gxfeng.springboot.common.exception.AuthException;
import com.gxfeng.springboot.common.exception.BusinessException;
import com.gxfeng.springboot.common.exception.NotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.validation.BindException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import javax.validation.ConstraintViolationException;
import java.util.UUID;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description 全局异常处理
 * @date 2021/12/14
 */
@Slf4j
@RestControllerAdvice("com.gxfeng")
public class WebRestControllerAdvice implements ResponseBodyAdvice<Result> {

    private static final String X_GXFENG_REQUEST_ID = "X-Gxfeng-Request-Id";

    @ExceptionHandler({HttpMessageNotReadableException.class,
            HttpRequestMethodNotSupportedException.class,
            ConstraintViolationException.class,
            MethodArgumentNotValidException.class,
            IllegalArgumentException.class,
            MissingServletRequestParameterException.class,
            BindException.class,
            NotFoundException.class,
            AuthException.class,
            BusinessException.class,
            RuntimeException.class,
            Exception.class})
    public Result<String> exception(Exception ex) {
        return Result.error(ex);
    }

    @Override
    public boolean supports(MethodParameter methodParameter, Class converterType) {
        boolean unFormat = methodParameter.getMethod().isAnnotationPresent(UnBodyAdvice.class);
        if (unFormat) {
            return false;
        }
        return true;
    }

    @Override
    public Result beforeBodyWrite(Result body, MethodParameter methodParameter, MediaType selectedContentType, Class selectedConverterType, ServerHttpRequest request, ServerHttpResponse response) {
        String requestId = null;
        if (request.getHeaders().containsKey(X_GXFENG_REQUEST_ID)) {
            requestId = request.getHeaders().getFirst(X_GXFENG_REQUEST_ID);
        }
        if (StringUtils.isBlank(requestId))
            requestId = UUID.randomUUID().toString();
        if (null == body) {
            body = Result.success();
        } else {
            body.setRequestId(requestId);
        }
        response.setStatusCode(body.getStatus());
        return body;
    }
}
