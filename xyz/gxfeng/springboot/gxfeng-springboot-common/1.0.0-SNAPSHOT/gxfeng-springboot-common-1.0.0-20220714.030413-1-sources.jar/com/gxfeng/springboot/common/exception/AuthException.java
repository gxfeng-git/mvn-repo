package com.gxfeng.springboot.common.exception;

import lombok.ToString;
import org.springframework.http.HttpStatus;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description auth认证异常类
 * @date 2021/12/14
 */
@ToString
public class AuthException extends Exception {

    public static final HttpStatus status = HttpStatus.OK;
    public static final String code = "100000";

    public AuthException() {
    }

    public AuthException(String message) {
        super(message);
    }
}
