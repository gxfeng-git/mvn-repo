package com.gxfeng.springboot.common;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public abstract class LimitVo<T> {

    /**
     * 当前页数
     */
    @ApiModelProperty(value = "当前页数", example = "1")
    private Integer pageNum = 1;

    /**
     * 显示条数
     */
    @ApiModelProperty(value = "显示条数", example = "10")
    private Integer pageSize = 10;

    @ApiModelProperty(hidden = true)
    public IPage<T> getPage() {
        return Page.of(this.pageNum, this.pageSize);
    }
}
