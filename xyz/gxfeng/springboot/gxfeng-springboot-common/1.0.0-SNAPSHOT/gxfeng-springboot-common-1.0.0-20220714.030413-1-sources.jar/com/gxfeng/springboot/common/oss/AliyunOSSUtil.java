package com.gxfeng.springboot.common.oss;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.common.auth.DefaultCredentialProvider;
import com.aliyun.oss.model.CannedAccessControlList;
import com.aliyun.oss.model.OSSObject;
import com.aliyun.oss.model.ObjectMetadata;
import com.aliyun.oss.model.PutObjectRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * @version V1.0
 * Java API文档地址：https://help.aliyun.com/document_detail/32008.html?spm=a2c4g.11186623.6.703.238374b4PsMzWf
 * @description: 阿里云OSS服务相关工具类.
 * @date: 2019年3月29日15:18:33
 */
@Slf4j
@Component
public class AliyunOSSUtil {

    private static String ACCESS_KEY_ID;
    private static String ACCESS_KEY_SECRET;
    private static String ENDPOINT;
    private static String BUCKETNAME;

    @Autowired(required = false)
    private AliyunOSSConfig aliyunOSSConfig;

    private static OSS getOssClient() {
        return OSSClientBuilder.create()
                .endpoint(ENDPOINT)
                .credentialsProvider(new DefaultCredentialProvider(ACCESS_KEY_ID, ACCESS_KEY_SECRET))
                .build();
    }

    private static String getFileName(String extension, String sourceType) {
        extension = (extension.startsWith(".") ? extension : ("." + extension));
        return sourceType + "/" + System.currentTimeMillis() + extension;
    }

    public static String uploadFile(InputStream input, String fileName) {
        OSS ossClient = getOssClient();
        PutObjectRequest putObjectRequest = new PutObjectRequest(BUCKETNAME, fileName, input);
        ossClient.putObject(putObjectRequest);
        ossClient.shutdown();
        return getFilePath(fileName);
    }

    public static String uploadFile(InputStream input, String extension, String sourceType) {
        String fileName = getFileName(extension, sourceType);
        return uploadFile(input, fileName);
    }

    public static String uploadFile(File file, String fileName) {
        OSS ossClient = getOssClient();
        PutObjectRequest putObjectRequest = new PutObjectRequest(BUCKETNAME, fileName, file);
        ossClient.putObject(putObjectRequest);
        ossClient.shutdown();
        if (file.exists()) {
            file.delete();
        }
        return getFilePath(fileName);
    }

    public static String uploadFile(File file, String extension, String sourceType) {
        String fileName = getFileName(extension, sourceType);
        return uploadFile(file, fileName);
    }

    public static String getFilePath(String path) {
        return "https://" + BUCKETNAME + "." + ENDPOINT + "/" + path;
    }

    public static String uploadExportJson(String json, String key) {
        ByteArrayInputStream inputStream = new ByteArrayInputStream(json.getBytes());
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentType("application/json");
        return uploadExport(inputStream, "json", key, metadata);
    }

    public static String uploadExportExcel(InputStream inputStream, String key) {
        return uploadExport(inputStream, "xlsx", key, null);
    }

    public static String uploadExportPdf(InputStream inputStream, String key) {
        return uploadExport(inputStream, "pdf", key, null);
    }

    public static String uploadExportImage(InputStream inputStream, String key, String suffix) {
        return uploadExport(inputStream, suffix, key, null);
    }

    public static String uploadExport(InputStream inputStream, String suffix, String key, ObjectMetadata objectMetadata) {
        if (StringUtils.isBlank(key)) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            String date = format.format(new Date());
            key = String.format("export/%s/%s.%s", date, UUID.randomUUID(), suffix);
        } else {
            key = String.format("%s.%s", key, suffix);
        }
        // 创建OSSClient实例。
        OSS ossClient = getOssClient();
        // 上传文件
        ossClient.putObject(BUCKETNAME, key, inputStream, objectMetadata);
        // 设置权限(公开读)
        ossClient.setBucketAcl(BUCKETNAME, CannedAccessControlList.PublicRead);
        ossClient.shutdown();
        // 设置文件路径和名称
        return getFilePath(key);
    }

    /**
     * @param url 文件oss完整地址
     * @return
     */
    public static String getFileRelativePath(String url) {
        return StringUtils.substringAfter(url, "https://" + BUCKETNAME + "." + ENDPOINT + "/");
    }

    /**
     * @param urls     文件oss完成地址或者相对地址
     * @param fileName zip包文件名称
     * @return zip包oss地址
     * @throws IOException
     */
    public static String batchDownloadFile2Zip(final List<String> urls, final String fileName) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ZipOutputStream zipOutputStream = new ZipOutputStream(byteArrayOutputStream);
        for (String url : urls) {
            String key = getFileRelativePath(url);
            OSSObject ossObject = getOssClient().getObject(BUCKETNAME, key);
            ZipEntry zipEntry = new ZipEntry(key);
            zipOutputStream.putNextEntry(zipEntry);
            IOUtils.copy(ossObject.getObjectContent(), zipOutputStream);
            ossObject.close();
        }
        zipOutputStream.closeEntry();
        zipOutputStream.finish();
        return uploadFile(new ByteArrayInputStream(byteArrayOutputStream.toByteArray()), fileName);
    }

    @PostConstruct
    private void init() {
        if (null != aliyunOSSConfig) {
            this.ACCESS_KEY_ID = aliyunOSSConfig.getAccessKeyId();
            this.ACCESS_KEY_SECRET = aliyunOSSConfig.getAccessKeySecret();
            this.ENDPOINT = aliyunOSSConfig.getEndpoint();
            this.BUCKETNAME = aliyunOSSConfig.getBucketName();
        }
    }
}
