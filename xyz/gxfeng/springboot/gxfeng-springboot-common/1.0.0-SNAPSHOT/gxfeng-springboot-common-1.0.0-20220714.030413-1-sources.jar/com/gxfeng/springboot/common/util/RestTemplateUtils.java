package com.gxfeng.springboot.common.util;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.DefaultUriBuilderFactory;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description
 * @date 2021/10/30
 */
@Slf4j
public class RestTemplateUtils {

    private static RequestConfig requestConfig = null;
    private static PoolingHttpClientConnectionManager cm = null;

    // 连接池的总连接数
    private static int HTTP_MAX_TOTAL_CONNECTION = 2000;
    // 连接池对每个主机的最大连接数
    private static int HTTP_MAX_CONNECTION_PER_ROUTE = 2000;
    // 连接的超时时间
    private static int HTTP_CONNECTION_TIMEOUT = 60000;
    // 连接传输数据的超时时间
    private static int HTTP_SO_TIMEOUT = 300000;
    private static final RestTemplate REST_TEMPLATE = new RestTemplate() {{
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientRestfulHttpRequestFactory(httpClient());
        setRequestFactory(requestFactory);
        setUriTemplateHandler(new DefaultUriBuilderFactory());
        List<HttpMessageConverter<?>> httpMessageConverters = getMessageConverters();
        httpMessageConverters.stream().forEach(httpMessageConverter -> {
            if (httpMessageConverter instanceof StringHttpMessageConverter) {
                StringHttpMessageConverter messageConverter = (StringHttpMessageConverter) httpMessageConverter;
                messageConverter.setDefaultCharset(Charset.forName("UTF-8"));
            }
        });
    }};

    private static RequestConfig getRequestConfig(int httpConnectionTimeout, int httpSocketTimeout) {
        if (requestConfig == null) {
            requestConfig = RequestConfig.custom().setConnectTimeout(httpConnectionTimeout).setSocketTimeout(httpSocketTimeout).build();
        }
        return requestConfig;
    }

    private static PoolingHttpClientConnectionManager getConnectionManager() {
        if (cm == null) {
            cm = new PoolingHttpClientConnectionManager();
            cm.setMaxTotal(HTTP_MAX_TOTAL_CONNECTION);
            cm.setDefaultMaxPerRoute(HTTP_MAX_CONNECTION_PER_ROUTE);
            cm.setValidateAfterInactivity(HTTP_CONNECTION_TIMEOUT);
        }
        return cm;
    }

    private static HttpClient httpClient() {
        return HttpClientBuilder.create().setDefaultRequestConfig(getRequestConfig(HTTP_CONNECTION_TIMEOUT, HTTP_SO_TIMEOUT)).setConnectionManager(getConnectionManager()).build();
    }

    private static <T> T exchange(RequestEntity<?> requestEntity, Class<T> responseType) {
        UUID uuid = UUID.randomUUID();
        log.info("请求开始,请求id: {}, uri: {}, method: {}, headers: {}, body: {}", uuid, requestEntity.getUrl(), requestEntity.getMethod(), requestEntity.getHeaders(), requestEntity.getBody());
        ResponseEntity<T> exchange = null;
        String responseBody = null;
        HttpStatus httpStatus = null;
        try {
            exchange = REST_TEMPLATE.exchange(requestEntity, responseType);
        } catch (RestClientException e) {
            log.error("请求异常,请求id: {}", uuid, e);
            if (e instanceof HttpStatusCodeException) {
                httpStatus = ((HttpStatusCodeException) e).getStatusCode();
                responseBody = ((HttpStatusCodeException) e).getResponseBodyAsString();
            } else {
                throw e;
            }
        }
        T response = null;
        if (exchange != null) {
            httpStatus = exchange.getStatusCode();
            response = exchange.getBody();
        } else {
            try {
                response = JSONObject.parseObject(responseBody, responseType);
            } catch (JSONException e) {
                response = responseType.cast(responseBody);
            }
        }
        if (!responseType.isAssignableFrom(Resource.class)) {
            log.info("请求结束,请求id: {},httpStatus: {}, response: {}", uuid, httpStatus, response);
        } else {
            log.info("请求结束,请求id: {},httpStatus: {}", uuid, httpStatus);
        }
        return response;
    }

    /**
     * 获取RestTemplate实例对象，可自由调用其方法
     *
     * @return RestTemplate实例对象
     */
    public static RestTemplate getRestTemplate() {
        return REST_TEMPLATE;
    }

    public static <T> T exchange(String url, HttpMethod method, Map<String, String> headers, Map<String, Object> queryParams, Object body, Class<T> responseType) {
        return exchange(url, method, headers, queryParams, body, responseType, new HashMap<>());
    }

    public static <T> T exchange(String url, HttpMethod method, Map<String, String> headers, Map<String, Object> queryParams, Object body, Class<T> responseType, Map<String, ?> uriVariables) {
        HttpHeaders httpHeaders = new HttpHeaders();
        if (null == headers) {
            headers = new HashMap<>();
        }
        if (!headers.containsKey("Accept") && !headers.containsKey("accept")) {
            headers.putIfAbsent("Accept", "*/*");
        }
        if (!headers.containsKey("Content-Type") && !headers.containsKey("content-type")) {
            headers.putIfAbsent("Content-Type", "application/json;charset=UTF-8");
        }
        httpHeaders.setAll(headers);
        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        if (null != queryParams) {
            Map<String, String> tmpMap = new HashMap<>();
            if (!queryParams.isEmpty()) {
                queryParams.forEach((k, v) -> {
                    if (v != null) {
                        tmpMap.put(k, v.toString());
                    }
                });
            }
            params.setAll(tmpMap);
        }
        if (null == uriVariables) {
            uriVariables = new HashMap<>();
        }
        if (MediaType.APPLICATION_FORM_URLENCODED.includes(httpHeaders.getContentType())) {
            MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
            if (null != body) {
                Map<String, Object> jsonObject;
                if (body instanceof Map) {
                    jsonObject = (Map<String, Object>) body;
                } else if (body instanceof String) {
                    jsonObject = JSONObject.parseObject((String) body);
                } else {
                    jsonObject = JSONObject.parseObject(JSONObject.toJSONString(body));
                }
                map.setAll(jsonObject);
            }
            body = map;
        }
        URI uri = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build(uriVariables);
        RequestEntity<?> requestEntity = new RequestEntity<>(body, httpHeaders, method, uri);
        return exchange(requestEntity, responseType);
    }

    public static <T> T get(String url, Class<T> clz) {
        return get(url, null, null, clz);
    }

    public static <T> T get(String url, Map<String, Object> params, Class<T> clz) {
        return get(url, null, params, clz);
    }

    public static <T> T get(String url, Map<String, String> headers, Map<String, Object> params, Class<T> clz) {
        return exchange(url, HttpMethod.GET, headers, params, null, clz);
    }

    public static String getString(String url) {
        return getString(url, null, null);
    }

    public static String getString(String url, Map<String, Object> params) {
        return getString(url, null, params);
    }

    public static String getString(String url, Map<String, String> headers, Map<String, Object> params) {
        return exchange(url, HttpMethod.GET, headers, params, null, String.class);
    }

    public static JSONObject getJSONObject(String url) {
        return getJSONObject(url, null, null);
    }

    public static JSONObject getJSONObject(String url, Map<String, Object> params) {
        return getJSONObject(url, null, params);
    }

    public static JSONObject getJSONObject(String url, Map<String, String> headers, Map<String, Object> params) {
        return exchange(url, HttpMethod.GET, headers, params, null, JSONObject.class);
    }

    public static Resource getResource(String url) {
        return getResource(url, null, null);
    }

    public static Resource getResource(String url, Map<String, Object> params) {
        return getResource(url, null, params);
    }

    public static Resource getResource(String url, Map<String, String> headers, Map<String, Object> params) {
        return exchange(url, HttpMethod.GET, headers, params, null, Resource.class);
    }

    public static <T> T post(String url, Class<T> clz) {
        return post(url, null, null, clz);
    }

    public static <T> T post(String url, Object body, Class<T> clz) {
        return post(url, null, body, clz);
    }

    public static <T> T post(String url, Map<String, String> headers, Object body, Class<T> clz) {
        return exchange(url, HttpMethod.POST, headers, null, body, clz);
    }

    public static String postString(String url) {
        return postString(url, null, null);
    }

    public static String postString(String url, Object body) {
        return postString(url, null, body);
    }

    public static String postString(String url, Map<String, String> headers, Object body) {
        return exchange(url, HttpMethod.POST, headers, null, body, String.class);
    }

    public static JSONObject postJSONObject(String url) {
        return postJSONObject(url, null, null);
    }

    public static JSONObject postJSONObject(String url, Object body) {
        return postJSONObject(url, null, body);
    }

    public static JSONObject postJSONObject(String url, Map<String, String> headers, Object body) {
        return exchange(url, HttpMethod.POST, headers, null, body, JSONObject.class);
    }

    public static Resource postResource(String url) {
        return postResource(url, null, null);
    }

    public static Resource postResource(String url, Object body) {
        return postResource(url, null, body);
    }

    public static Resource postResource(String url, Map<String, String> headers, Object body) {
        return exchange(url, HttpMethod.POST, headers, null, body, Resource.class);
    }
}
