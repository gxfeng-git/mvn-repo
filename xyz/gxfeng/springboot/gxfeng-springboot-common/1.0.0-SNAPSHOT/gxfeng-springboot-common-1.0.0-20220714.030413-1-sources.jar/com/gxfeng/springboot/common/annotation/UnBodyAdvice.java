package com.gxfeng.springboot.common.annotation;

import java.lang.annotation.*;

/**
 * @author gxfeng <gxfeng@gongsibao.com>
 * @description 不参与统一响应处理结果
 * @date 2022/6/28
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface UnBodyAdvice {
}
